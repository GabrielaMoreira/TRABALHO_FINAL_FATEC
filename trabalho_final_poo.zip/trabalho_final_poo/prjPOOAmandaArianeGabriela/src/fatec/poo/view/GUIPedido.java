package fatec.poo.view;

import fatec.poo.control.Conexao;
import fatec.poo.control.DaoCliente;
import fatec.poo.control.DaoItemPedido;
import fatec.poo.control.DaoPedido;
import fatec.poo.control.DaoProduto;
import fatec.poo.control.DaoVendedor;

import fatec.poo.model.Cliente;
import fatec.poo.model.ItemPedido;
import fatec.poo.model.Pedido;
import fatec.poo.model.Produto;
import fatec.poo.model.Vendedor;

import static fatec.poo.model.Produto.VerificaCodigo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/* @author 0030481721009 */
public class GUIPedido extends javax.swing.JFrame {

    public GUIPedido() {
        initComponents();
        modTblItem = (DefaultTableModel) tblItemPedido.getModel();
        this.setLocationRelativeTo(null);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btgPagamento = new javax.swing.ButtonGroup();
        Panel_Pedido = new javax.swing.JPanel();
        Panel_Pagamento = new javax.swing.JPanel();
        rbnVista = new javax.swing.JRadioButton();
        rbnPrazo = new javax.swing.JRadioButton();
        txfData = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        txtNumPedido = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        btnConsultarPedido = new javax.swing.JButton();
        Panel_Cliente = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txfCPFCliente = new javax.swing.JFormattedTextField();
        btnConsultarCliente = new javax.swing.JButton();
        txtNomeCliente = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Panel_Vendedor = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txfCPFVendedor = new javax.swing.JFormattedTextField();
        btnConsultarVendedor = new javax.swing.JButton();
        txtNomeVendedor = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Panel_Item_Pedido = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtCodigoProduto = new javax.swing.JTextField();
        btnConsultarProduto = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txtDescricaoProduto = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtQtdVendida = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblItemPedido = new javax.swing.JTable();
        btnAdicionar = new javax.swing.JButton();
        btnRemover = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtTotalPedido = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtQtdItem = new javax.swing.JTextField();
        btnIncluir = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Emitir Pedido");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        Panel_Pedido.setBorder(javax.swing.BorderFactory.createTitledBorder("Pedido"));

        Panel_Pagamento.setBorder(javax.swing.BorderFactory.createTitledBorder("Forma de Pagamento"));

        btgPagamento.add(rbnVista);
        rbnVista.setText("A Vista");
        rbnVista.setEnabled(false);
        rbnVista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbnVistaActionPerformed(evt);
            }
        });

        btgPagamento.add(rbnPrazo);
        rbnPrazo.setText("A Prazo");
        rbnPrazo.setEnabled(false);
        rbnPrazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbnPrazoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Panel_PagamentoLayout = new javax.swing.GroupLayout(Panel_Pagamento);
        Panel_Pagamento.setLayout(Panel_PagamentoLayout);
        Panel_PagamentoLayout.setHorizontalGroup(
            Panel_PagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_PagamentoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rbnVista)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(rbnPrazo)
                .addContainerGap())
        );
        Panel_PagamentoLayout.setVerticalGroup(
            Panel_PagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_PagamentoLayout.createSequentialGroup()
                .addGroup(Panel_PagamentoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbnVista)
                    .addComponent(rbnPrazo))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        try {
            txfData.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txfData.setEnabled(false);
        txfData.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txfDataFocusLost(evt);
            }
        });

        jLabel1.setText("Num. Pedido");

        jLabel2.setText("Data de Emissão");

        btnConsultarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/pesq.png"))); // NOI18N
        btnConsultarPedido.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConsultarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarPedidoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Panel_PedidoLayout = new javax.swing.GroupLayout(Panel_Pedido);
        Panel_Pedido.setLayout(Panel_PedidoLayout);
        Panel_PedidoLayout.setHorizontalGroup(
            Panel_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_PedidoLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(txtNumPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnConsultarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txfData, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Panel_Pagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        Panel_PedidoLayout.setVerticalGroup(
            Panel_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addGroup(Panel_PedidoLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(btnConsultarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Panel_PedidoLayout.createSequentialGroup()
                    .addGap(19, 19, 19)
                    .addGroup(Panel_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txfData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)
                        .addComponent(txtNumPedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2))))
            .addComponent(Panel_Pagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        Panel_PedidoLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnConsultarPedido, txtNumPedido});

        Panel_Cliente.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Cliente"));

        jLabel3.setText("CPF Cliente");

        try {
            txfCPFCliente.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txfCPFCliente.setEnabled(false);

        btnConsultarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/pesq.png"))); // NOI18N
        btnConsultarCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConsultarCliente.setEnabled(false);
        btnConsultarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarClienteActionPerformed(evt);
            }
        });

        txtNomeCliente.setEnabled(false);

        jLabel4.setText("Nome Cliente");

        javax.swing.GroupLayout Panel_ClienteLayout = new javax.swing.GroupLayout(Panel_Cliente);
        Panel_Cliente.setLayout(Panel_ClienteLayout);
        Panel_ClienteLayout.setHorizontalGroup(
            Panel_ClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_ClienteLayout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(jLabel3)
                .addGap(26, 26, 26)
                .addComponent(txfCPFCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnConsultarCliente)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(txtNomeCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Panel_ClienteLayout.setVerticalGroup(
            Panel_ClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_ClienteLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Panel_ClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel_ClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtNomeCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4))
                    .addGroup(Panel_ClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txfCPFCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3))
                    .addComponent(btnConsultarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        Panel_ClienteLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnConsultarCliente, txfCPFCliente});

        Panel_Vendedor.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Cliente"));

        jLabel5.setText("CPF Vendedor");

        try {
            txfCPFVendedor.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txfCPFVendedor.setEnabled(false);

        btnConsultarVendedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/pesq.png"))); // NOI18N
        btnConsultarVendedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConsultarVendedor.setEnabled(false);
        btnConsultarVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarVendedorActionPerformed(evt);
            }
        });

        txtNomeVendedor.setEnabled(false);

        jLabel6.setText("Nome Vendedor");

        javax.swing.GroupLayout Panel_VendedorLayout = new javax.swing.GroupLayout(Panel_Vendedor);
        Panel_Vendedor.setLayout(Panel_VendedorLayout);
        Panel_VendedorLayout.setHorizontalGroup(
            Panel_VendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_VendedorLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txfCPFVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnConsultarVendedor)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtNomeVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Panel_VendedorLayout.setVerticalGroup(
            Panel_VendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_VendedorLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Panel_VendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel_VendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtNomeVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6))
                    .addGroup(Panel_VendedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txfCPFVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5))
                    .addComponent(btnConsultarVendedor, javax.swing.GroupLayout.PREFERRED_SIZE, 22, Short.MAX_VALUE))
                .addContainerGap())
        );

        Panel_Item_Pedido.setBorder(javax.swing.BorderFactory.createTitledBorder("Itens do Pedido"));

        jLabel7.setText("Codigo Produto");

        txtCodigoProduto.setEnabled(false);

        btnConsultarProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/pesq.png"))); // NOI18N
        btnConsultarProduto.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConsultarProduto.setEnabled(false);
        btnConsultarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarProdutoActionPerformed(evt);
            }
        });

        jLabel8.setText("Descrição Produto");

        txtDescricaoProduto.setEnabled(false);

        jLabel9.setText("QTD. Vendida");

        txtQtdVendida.setEnabled(false);

        tblItemPedido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CODIGO", "DESCRIÇÃO", "PREÇO UNIT.", "QTD. VENDIDA", "SUB_TOTAL"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblItemPedido.setEnabled(false);
        jScrollPane1.setViewportView(tblItemPedido);

        btnAdicionar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/add.png"))); // NOI18N
        btnAdicionar.setText("Adicionar Item");
        btnAdicionar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAdicionar.setEnabled(false);
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });

        btnRemover.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/rem.png"))); // NOI18N
        btnRemover.setText("Remover Item");
        btnRemover.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRemover.setEnabled(false);
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });

        jLabel10.setText("Valor Total do Pedido");

        txtTotalPedido.setEnabled(false);

        jLabel11.setText("Quantidade de Itens do Pedido");

        txtQtdItem.setEnabled(false);

        javax.swing.GroupLayout Panel_Item_PedidoLayout = new javax.swing.GroupLayout(Panel_Item_Pedido);
        Panel_Item_Pedido.setLayout(Panel_Item_PedidoLayout);
        Panel_Item_PedidoLayout.setHorizontalGroup(
            Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_Item_PedidoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(Panel_Item_PedidoLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCodigoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnConsultarProduto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDescricaoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtQtdVendida, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(Panel_Item_PedidoLayout.createSequentialGroup()
                        .addComponent(btnAdicionar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRemover))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_Item_PedidoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_Item_PedidoLayout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtTotalPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_Item_PedidoLayout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtQtdItem, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(87, 87, 87)))))
                .addContainerGap())
        );
        Panel_Item_PedidoLayout.setVerticalGroup(
            Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel_Item_PedidoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtDescricaoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8)
                        .addComponent(jLabel9)
                        .addComponent(txtQtdVendida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(txtCodigoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnConsultarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdicionar)
                    .addComponent(btnRemover))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotalPedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Panel_Item_PedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtQtdItem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)))
        );

        Panel_Item_PedidoLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnConsultarProduto, txtCodigoProduto});

        btnIncluir.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/add.png"))); // NOI18N
        btnIncluir.setText("Incluir");
        btnIncluir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnIncluir.setEnabled(false);
        btnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIncluirActionPerformed(evt);
            }
        });

        btnAlterar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/Alterar.png"))); // NOI18N
        btnAlterar.setText("Alterar");
        btnAlterar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAlterar.setEnabled(false);
        btnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarActionPerformed(evt);
            }
        });

        btnExcluir.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/Eraser.png"))); // NOI18N
        btnExcluir.setText("Excluir");
        btnExcluir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnExcluir.setEnabled(false);
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnSair.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fatec/poo/view/icon/exit.png"))); // NOI18N
        btnSair.setMnemonic('S');
        btnSair.setText("Sair");
        btnSair.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnIncluir)
                        .addGap(15, 15, 15)
                        .addComponent(btnAlterar)
                        .addGap(15, 15, 15)
                        .addComponent(btnExcluir)
                        .addGap(15, 15, 15)
                        .addComponent(btnSair))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(Panel_Pedido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Panel_Item_Pedido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Panel_Vendedor, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(Panel_Cliente, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnExcluir, btnSair});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Panel_Pedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Panel_Cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Panel_Vendedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Panel_Item_Pedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnIncluir)
                    .addComponent(btnAlterar)
                    .addComponent(btnExcluir)
                    .addComponent(btnSair))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        dispose();
    }//GEN-LAST:event_btnSairActionPerformed
        
    private void btnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIncluirActionPerformed
        
        int linhas;
        linhas = Integer.parseInt(txtQtdItem.getText());
        int cont = 0; 
        
        if(linhas == 0 || txtQtdItem.getText().isEmpty() || txtQtdItem.getText() == null){
            
            JOptionPane.showMessageDialog(null, "O pedido deve ter ao menos um item!", "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
            txtCodigoProduto.requestFocus();
            
        }else{
            
            cliente = null;
            cliente = daoCliente.consultar(txfCPFCliente.getText().replace(".", "").replace("-", ""));
            
            vendedor = null;
            vendedor = daoVendedor.consultar(txfCPFVendedor.getText().replace(".", "").replace("-", ""));
            
            //VERIFICANDO SE CLIENTE POSSUI CREDITO PARA EFETUAR PEDIDO
            if(Double.parseDouble(txtTotalPedido.getText()) > cliente.getLimiteDisp()){
                
                JOptionPane.showMessageDialog(null, "Pedido cancelado!\nCliente não possuí crédito disponível!\nLimide disponível de: " + cliente.getLimiteDisp(), "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
                                
            }else{
                
                //SALVANDO DADOS DO PEDIDO                 
                pedido = new Pedido(txtNumPedido.getText(), txfData.getText().replace("/", ""));
                pedido.setSituacao(true);
                //OBS: TRUE = A VISTA, FALSE = A PRAZO
                if(rbnVista.isSelected() == true){
                    pedido.setFormaPagto(true);
                    pedido.setDataPagto(txfData.getText().replace("/", ""));
                }
                else{ 
                    pedido.setFormaPagto(false);            
                    pedido.setDataPagto(txfData.getText().replace("/", ""));
                }
             
                pedido.setCliente(cliente);
                pedido.setVendedor(vendedor);

                daoPedido.inserir(pedido);

                //SALVANDO DADOS DO ITEM_PEDIDO E BAIXANDO ESTOQUE DOS PRODUTOS
                while(cont < linhas)
                {
                    produto = null;                
                    produto = daoProduto.consultar((String) modTblItem.getValueAt(cont, 0));
                    
                    item = new ItemPedido(cont+1, Double.parseDouble((String) modTblItem.getValueAt(cont, 3)), produto);
                    item.setPedido(pedido);
                    daoItemPedido.inserir(item);
                    
                    produto.setQtdeEstoque(produto.getQtdeEstoque() - Double.parseDouble((String) modTblItem.getValueAt(cont, 3)));
                    daoProduto.baixarEstoque(produto);
                    
                    cont++;
                }
                               
                //BAIXANDO LIMITE DISPONIVEL DE CLIENTE
                cliente.setLimiteDisp(cliente.getLimiteCred() - Double.parseDouble(txtTotalPedido.getText()));
                daoCliente.baixarLimite(cliente);
                
                JOptionPane.showMessageDialog(null, "Pedido efetuado com sucesso!", "ATENÇÃO", JOptionPane.INFORMATION_MESSAGE);
                
            }
                     

            //LIMPANDO TODOS OS CAMPOS
            txtNumPedido.setText("");
            txfData.setText("");
            btgPagamento.clearSelection();
            txfData.setText("");
            txfCPFCliente.setText("");
            txtNomeCliente.setText("");
            txfCPFVendedor.setText("");
            txtNomeVendedor.setText("");
            txtCodigoProduto.setText("");
            txtDescricaoProduto.setText("");
            txtQtdVendida.setText("");
            txtQtdItem.setText("");
            txtTotalPedido.setText("");
            qtdLinha = 0;
            valorTotal = 0;
            modTblItem.setNumRows(0);

            //DESABILITANDO CAMPOS
            txtNumPedido.setEnabled(true);
            txfData.setEnabled(false);
            rbnVista.setEnabled(false);
            rbnPrazo.setEnabled(false);
            txfData.setEnabled(false);
            txfCPFCliente.setEnabled(false);
            txfCPFVendedor.setEnabled(false);
            txtCodigoProduto.setEnabled(false);
            txtQtdVendida.setEnabled(false);
            tblItemPedido.setEnabled(false);

            btnConsultarPedido.setEnabled(true);
            btnConsultarCliente.setEnabled(false);              
            btnConsultarVendedor.setEnabled(false);
            btnConsultarProduto.setEnabled(false);
            btnAdicionar.setEnabled(false);
            btnRemover.setEnabled(false);

            btnIncluir.setEnabled(false);
            btnSair.setEnabled(true);
            btnAlterar.setEnabled(false);
            btnExcluir.setEnabled(false);

            txtNumPedido.requestFocus();
 
            }        
    }//GEN-LAST:event_btnIncluirActionPerformed

    private void btnConsultarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarPedidoActionPerformed
          
        if(txtNumPedido.getText() == null || txtNumPedido.getText().isEmpty()){
            
            JOptionPane.showMessageDialog(null, "Informe um pedido!", "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
            txtNumPedido.requestFocus();
            
        }else{
            pedido = null;
            pedido = daoPedido.consultar(txtNumPedido.getText());
            int cont = 0, linhas;
            
            //PEDIDO NÃO ENCONTRADO (HABILITA CAMPOS)
            if(pedido == null){
                
                txtNumPedido.setEnabled(false);
                txfData.setEnabled(true);
                rbnVista.setEnabled(true);
                rbnPrazo.setEnabled(true);
                rbnVista.setSelected(false);
                rbnPrazo.setSelected(false);
                               
                btnConsultarPedido.setEnabled(false);
                
                btnIncluir.setEnabled(true);
                btnSair.setEnabled(true);
                btnAlterar.setEnabled(false);
                btnExcluir.setEnabled(false);
             
            //PEDIDO ENCONTRADO (PREENCHE CAMPOS)
            }else{

                txtNumPedido.setEnabled(false);
                btnConsultarPedido.setEnabled(false);
                
                txfData.setText(pedido.getDataEmissao());                
                txfCPFCliente.setText(pedido.getCliente().getCpf());
                txtNomeCliente.setText(pedido.getCliente().getNome());
                txfCPFVendedor.setText(pedido.getVendedor().getCpf());
                txtNomeVendedor.setText(pedido.getVendedor().getNome()); 
                
                //OBS: TRUE = A VISTA, FALSE = A PRAZO
                if(pedido.isFormaPagto() == true){
                    rbnVista.setSelected(true);                   
                }
                else{
                    rbnPrazo.setSelected(true);                    
                }
                
                //DECLARANDO LISTA DE ITENS E PESQUISANDO NA DAO_ITEM_PEDIDO
                ArrayList<ItemPedido> itenspedido = new ArrayList<ItemPedido>();
                itenspedido = daoItemPedido.consultar(pedido);
                
                //PREENCHENDO GRID COM ITENS DO PEDIDO
                for (int x = 0; x < itenspedido.size(); x++) {
                    
                    item = itenspedido.get(x);
                    
                    String Linha[] = {
                        item.getProduto().getCodigo(),
                        item.getProduto().getDescricao(),
                        String.valueOf(item.getProduto().getPreco()),
                        String.valueOf(item.getQtdeVendida()),
                        String.valueOf(item.getProduto().getPreco() * item.getQtdeVendida())
                    };
                 modTblItem.addRow(Linha);
                }         
                                         
                //CALCULA TOTAL PRODUTOS DA GRID
                linhas = modTblItem.getRowCount();
                txtQtdItem.setText(String.valueOf(linhas));
                
                while(cont < linhas){
                    valorTotal += Double.parseDouble((String) modTblItem.getValueAt(cont, 4));
                    cont++;
                }
                txtTotalPedido.setText(String.valueOf(valorTotal));                
                
                tblItemPedido.setEnabled(true);
                txtCodigoProduto.setEnabled(true);
                txtQtdVendida.setEnabled(true);
                
                btnConsultarProduto.setEnabled(true);
                btnAdicionar.setEnabled(true);
                btnRemover.setEnabled(true);
                btnAlterar.setEnabled(true);
                btnExcluir.setEnabled(true);
            }
        }
    }//GEN-LAST:event_btnConsultarPedidoActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        conexao = new Conexao("BD1721003","BD1721003");        
        conexao.setDriver("oracle.jdbc.driver.OracleDriver");
        conexao.setConnectionString("jdbc:oracle:thin:@apolo:1521:xe");
        daoPedido = new DaoPedido(conexao.conectar());
        daoProduto = new DaoProduto(conexao.conectar());
        daoItemPedido = new DaoItemPedido(conexao.conectar());
        daoCliente = new DaoCliente(conexao.conectar());
        daoVendedor = new DaoVendedor(conexao.conectar());
    }//GEN-LAST:event_formWindowOpened

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        conexao.fecharConexao();
        dispose();
    }//GEN-LAST:event_formWindowClosed

    private void btnConsultarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarProdutoActionPerformed
        
        if(txtCodigoProduto.getText() == null || txtCodigoProduto.getText().isEmpty() || VerificaCodigo(txtCodigoProduto.getText()) == false){
            
            JOptionPane.showMessageDialog(null, "Informe um codigo válido!\nDica: Informe apenas números.", "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
            txtCodigoProduto.requestFocus();
            txtDescricaoProduto.setText("");
            txtQtdVendida.setText("");
            txtQtdVendida.setEnabled(false);
            
        }else{
            produto = null;
            produto = daoProduto.consultar(txtCodigoProduto.getText());
            
            //PRODUTO NÃO ENCONTRADO (MENSAGEM DE ALERTA)
            if(produto == null){
                
                JOptionPane.showMessageDialog(null, "Produto não encontrado!", "ATENÇÃO", JOptionPane.ERROR_MESSAGE);
                txtCodigoProduto.requestFocus();
                txtCodigoProduto.setText("");
                txtDescricaoProduto.setText("");
                txtQtdVendida.setText("");
                txtQtdVendida.setEnabled(false);
                
                btnAdicionar.setEnabled(false);
                btnRemover.setEnabled(false);
             
            //PRODUTO ENCONTRADO (PREENCHE CAMPOS)
            }else{
                
                txtDescricaoProduto.setText(produto.getDescricao());
                txtQtdVendida.setText("1");
                txtQtdVendida.setEnabled(true);
                txtQtdVendida.requestFocus();
                
                tblItemPedido.setEnabled(true);
                btnAdicionar.setEnabled(true);
                btnRemover.setEnabled(true);
            }
        }
    }//GEN-LAST:event_btnConsultarProdutoActionPerformed
    
    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarActionPerformed
        
        double subTotal;
        double precoUnitario;
        int linhas = modTblItem.getRowCount();
        txtQtdItem.setText(String.valueOf(linhas));
        
        if(txtQtdVendida.getText().equals("0") || txtQtdVendida.getText().isEmpty() || txtQtdVendida.getText() == null){
            
            JOptionPane.showMessageDialog(null, "Informe uma quantidade válida!", "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
            txtQtdVendida.requestFocus();
            
        }else{
            
            //PRODUTO JÁ ADICIONADO (EVITAR ERRO DE CHAVE NO BD)
            if(procuraCodigo(txtCodigoProduto.getText()) == true){
                
                JOptionPane.showMessageDialog(null, "Produto já adicionado!", "ATENÇÃO", JOptionPane.ERROR_MESSAGE);
                txtCodigoProduto.setText("");
                txtDescricaoProduto.setText("");
                txtQtdVendida.setText("");
                txtCodigoProduto.requestFocus();
                
            }else{
                
                produto = null;
                produto = daoProduto.consultar(txtCodigoProduto.getText());
                
                //VERIFICA SE QUANTIDADE INFORMADA POSSUI EM ESOTQUE
                if(Double.parseDouble(txtQtdVendida.getText()) > produto.getQtdeEstoque()){
                    
                    JOptionPane.showMessageDialog(null, "Quantidade informada não disponível em estoque!\nQuantidade em estoque de: " + produto.getQtdeEstoque(), "ATENÇÂO", JOptionPane.WARNING_MESSAGE);
                    
                    if(produto.getQtdeEstoque() > 1){
                        
                        txtQtdVendida.setText("1");
                        txtQtdVendida.requestFocus();
                        
                    }else{
                        
                        txtCodigoProduto.setText("");
                        txtDescricaoProduto.setText("");
                        txtQtdVendida.setText("");

                        txtCodigoProduto.requestFocus();
                        btnAdicionar.setEnabled(false);
                        
                    }                    
                    
                }else{
                    
                    //ATRIBUINDO VALORES DAS COLUNAS PRECO_UNITARIO, SUB_TOTAL NAS VARIAVEIS
                    precoUnitario = produto.getPreco();
                    subTotal = Double.parseDouble(txtQtdVendida.getText()) * precoUnitario;
                    valorTotal += subTotal;

                    //ADICIONANDO PRODUTO A GRID
                    String Linha[] = {
                        txtCodigoProduto.getText(),
                        txtDescricaoProduto.getText(),
                        String.valueOf(precoUnitario),
                        txtQtdVendida.getText(),
                        String.valueOf(subTotal)
                    };

                    modTblItem.addRow(Linha);
                    linhas++;

                    txtTotalPedido.setText(String.valueOf(valorTotal));
                    txtQtdItem.setText(String.valueOf(linhas));
                    
                    txtCodigoProduto.setText("");
                    txtDescricaoProduto.setText("");
                    txtQtdVendida.setText("");

                    txtCodigoProduto.requestFocus();
                    btnAdicionar.setEnabled(false);
                }
            }            
        }
    }//GEN-LAST:event_btnAdicionarActionPerformed

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverActionPerformed
        
        int linhas = modTblItem.getRowCount();
        txtQtdVendida.setText(String.valueOf(linhas));
        
        if(tblItemPedido.getSelectedRow() == -1){
         
            JOptionPane.showMessageDialog(null, "Selecione uma linha para exclusão!", "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
            txtCodigoProduto.requestFocus();
            
        }else{
            
            //SUBTRAI VALOR DO ITEM DO TOTAL
            valorTotal -= Double.parseDouble((String) modTblItem.getValueAt(tblItemPedido.getSelectedRow(), 4));
            txtTotalPedido.setText(String.valueOf(valorTotal));
            
            //EXCLUI ITEM DA GRID
            modTblItem.removeRow(tblItemPedido.getSelectedRow());
            linhas--;            
            
            txtQtdItem.setText(String.valueOf(linhas));
            
        }
        
    }//GEN-LAST:event_btnRemoverActionPerformed

    private void btnConsultarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarClienteActionPerformed
        
        if(txfCPFCliente.getText() == null || txfCPFCliente.getText().isEmpty()){
            
            JOptionPane.showMessageDialog(null, "Informe o cpf do cliente!", "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
            txfCPFCliente.requestFocus();
            txtNomeCliente.setText("");
            
        } else{
            
            String cpf;
            cpf = txfCPFCliente.getText();
            cpf = cpf.replace(".", "").replace("-", "");

            cliente = null;
            cliente = daoCliente.consultar(cpf);
            
            if(cliente == null){
                
                JOptionPane.showMessageDialog(null, "CPF não encontrado!", "ATENÇÃO", JOptionPane.ERROR_MESSAGE);
                txfCPFCliente.requestFocus();
                txfCPFCliente.setText("");
                txtNomeCliente.setText("");
                
            }else{
                
                txtNomeCliente.setText(cliente.getNome());                
                
                txfCPFCliente.setEnabled(false);
                btnConsultarCliente.setEnabled(false);
                rbnPrazo.setEnabled(false);
                rbnVista.setEnabled(false);

                txfCPFVendedor.setEnabled(true);
                btnConsultarVendedor.setEnabled(true);
                txfCPFVendedor.requestFocus();
            }
        }
    }//GEN-LAST:event_btnConsultarClienteActionPerformed

    private void btnConsultarVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarVendedorActionPerformed
        
        if(txfCPFVendedor.getText() == null || txfCPFVendedor.getText().isEmpty()){
            
            JOptionPane.showMessageDialog(null, "Informe o cpf do vendedor!", "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
            txfCPFVendedor.requestFocus();
            txtNomeVendedor.setText("");
            
        }else{
            
            String cpf;
            cpf = txfCPFVendedor.getText();
            cpf = cpf.replace(".", "").replace("-", "");

            vendedor = null;
            vendedor = daoVendedor.consultar(cpf);

            if(vendedor == null){
                
                JOptionPane.showMessageDialog(null, "CPF não encontrado!", "ATENÇÃO", JOptionPane.ERROR_MESSAGE);
                txfCPFVendedor.requestFocus();
                txfCPFVendedor.setText("");
                txtNomeVendedor.setText("");
                
            }else{
                txtNomeVendedor.setText(vendedor.getNome());
                
                txfCPFVendedor.setEnabled(false);
                btnConsultarVendedor.setEnabled(false);
                
                txtCodigoProduto.setEnabled(true);
                btnConsultarProduto.setEnabled(true);
                txtCodigoProduto.requestFocus();
            }
        }
    }//GEN-LAST:event_btnConsultarVendedorActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        
        if(JOptionPane.showConfirmDialog(null, "Confirma Exclusão?") == 0){
            
            daoItemPedido.excluir(item);
            daoPedido.excluir(pedido);
            
            //LIMPANDO TODOS OS CAMPOS
            txtNumPedido.setText("");
            txfData.setText("");
            btgPagamento.clearSelection();
            txfCPFCliente.setText("");
            txtNomeCliente.setText("");
            txfCPFVendedor.setText("");
            txtNomeVendedor.setText("");
            txtCodigoProduto.setText("");
            txtDescricaoProduto.setText("");
            txtQtdVendida.setText("");
            txtQtdItem.setText("");
            txtTotalPedido.setText("");
            qtdLinha = 0;
            valorTotal = 0;
            modTblItem.setNumRows(0);
            
            //DESHABILITANDO CAMPOS
            txtNumPedido.setEnabled(true);
            txfData.setEnabled(false);
            rbnVista.setEnabled(false);
            rbnPrazo.setEnabled(false);
            txfCPFCliente.setEnabled(false);
            txfCPFVendedor.setEnabled(false);
            txtCodigoProduto.setEnabled(false);
            txtQtdVendida.setEnabled(false);
            tblItemPedido.setEnabled(false);
            txtNumPedido.requestFocus();
            
            btnConsultarPedido.setEnabled(true);
            btnConsultarCliente.setEnabled(false);              
            btnConsultarVendedor.setEnabled(false);
            btnConsultarProduto.setEnabled(false);
            btnAdicionar.setEnabled(false);
            btnRemover.setEnabled(false);
            
            btnIncluir.setEnabled(false);
            btnSair.setEnabled(true);
            btnAlterar.setEnabled(false);
            btnExcluir.setEnabled(false);
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        
        int linhas;
        linhas = Integer.parseInt(txtQtdItem.getText());
        
        if(linhas == 0){
                
                JOptionPane.showMessageDialog(null, "O pedido deve ter ao menos um item!", "ATENÇÃO", JOptionPane.WARNING_MESSAGE);
                txtCodigoProduto.requestFocus();
                
            }else{
                if(JOptionPane.showConfirmDialog(null, "Confirma Alteração?") == 0){

                    int cont = 0;
                
                    daoItemPedido.excluir(item);
                    while(cont < tblItemPedido.getRowCount())
                    {
                        produto = null;                
                        produto = daoProduto.consultar((String) modTblItem.getValueAt(cont, 0));                
                        item = new ItemPedido(cont+1, Double.parseDouble((String) modTblItem.getValueAt(cont, 3)), produto);
                        item.setPedido(pedido);
                        daoItemPedido.inserir(item);

                        cont++;
                    }

                    //LIMPANDO TODOS OS CAMPOS
                    txtNumPedido.setText("");
                    txfData.setText("");
                    rbnVista.setSelected(true);
                    rbnPrazo.setSelected(false);
                    txfCPFCliente.setText("");
                    txtNomeCliente.setText("");
                    txfCPFVendedor.setText("");
                    txtNomeVendedor.setText("");
                    txtCodigoProduto.setText("");
                    txtDescricaoProduto.setText("");
                    txtQtdVendida.setText("");
                    txtQtdItem.setText("");
                    txtTotalPedido.setText("");
                    qtdLinha = 0;
                    valorTotal = 0;
                    modTblItem.setNumRows(0);            

                    //DESHABILITANDO CAMPOS
                    txtNumPedido.setEnabled(true);
                    txfData.setEnabled(false);
                    rbnVista.setEnabled(true);
                    rbnPrazo.setEnabled(false);
                    txfCPFCliente.setEnabled(false);
                    txfCPFVendedor.setEnabled(false);
                    txtCodigoProduto.setEnabled(false);
                    txtQtdVendida.setEnabled(false);
                    tblItemPedido.setEnabled(false);

                    btnConsultarPedido.setEnabled(true);
                    btnConsultarCliente.setEnabled(false);              
                    btnConsultarVendedor.setEnabled(false);
                    btnConsultarProduto.setEnabled(false);
                    btnAdicionar.setEnabled(false);
                    btnRemover.setEnabled(false);

                    btnIncluir.setEnabled(false);
                    btnSair.setEnabled(true);
                    btnAlterar.setEnabled(false);
                    btnExcluir.setEnabled(false);                
            }            
        }
        
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void txfDataFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txfDataFocusLost
       
       /* String tam = txfData.getText();
        
        if(tam.length() == 10){
            if(validaData(txfData.getText()) == false){
                JOptionPane.showMessageDialog(null, "Data inválida!", "ATENÇÃO", JOptionPane.ERROR_MESSAGE);
                txfData.setText("");
                txfData.requestFocus();
            }else{
                txfData.setEnabled(false);
                txfCPFCliente.setEnabled(true);
                btnConsultarCliente.setEnabled(true);
                txfCPFCliente.requestFocus();
            }
        }*/
    }//GEN-LAST:event_txfDataFocusLost

    private void rbnVistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbnVistaActionPerformed
        String tam = txfData.getText();
        
        if(tam.length() == 10){
            if(validaData(txfData.getText()) == false){
                
                JOptionPane.showMessageDialog(null, "Data inválida!", "ATENÇÃO", JOptionPane.ERROR_MESSAGE);                
                btgPagamento.clearSelection();
                txfData.setText("");
                txfData.requestFocus();
                
            }else{       
                                
                txfData.setEnabled(false);
                txfCPFCliente.setEnabled(true);
                btnConsultarCliente.setEnabled(true);
                txfCPFCliente.requestFocus();
            }
        }
    }//GEN-LAST:event_rbnVistaActionPerformed

    private void rbnPrazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbnPrazoActionPerformed
        String tam = txfData.getText();
        
        if(tam.length() == 10){
            if(validaData(txfData.getText()) == false){
                
                JOptionPane.showMessageDialog(null, "Data inválida!", "ATENÇÃO", JOptionPane.ERROR_MESSAGE);                
                btgPagamento.clearSelection();
                txfData.setText("");
                txfData.requestFocus();
                
            }else{
                
                txfData.setEnabled(false);
                txfCPFCliente.setEnabled(true);
                btnConsultarCliente.setEnabled(true);
                txfCPFCliente.requestFocus();
            }
        }
    }//GEN-LAST:event_rbnPrazoActionPerformed
    
    
    //MÉTODO PARA CONSULTAR SE O PRODUTO JÁ FOI ADICIONADO A GRID (TRUE = JÁ ADICIONADO, FALSE = NÃO ADICIONADO) 
    public boolean procuraCodigo(String codigoProduto){
        
        boolean adicionado = false;
        int cont = 0, linhas;
        linhas = Integer.parseInt(txtQtdItem.getText());    
        
        while(cont < linhas){

            if(codigoProduto.equals(modTblItem.getValueAt(cont, 0))){
                adicionado = true;
                break;
            }
            cont++;
        }            
        
        return(adicionado);        
    }  
    
    //MÉTODO PARA VALIDAR DATA DE EMISSAO (TRUE = VALIDA, FALSE = INVALIDA)
    public boolean validaData(String dataEmissao){
        
        try {
            
            SimpleDateFormat data = new SimpleDateFormat("dd/MM/yyyy");
            data.setLenient(false);
            data.parse(dataEmissao);
            return true;
            
        } catch (ParseException ex) {            
            return false;
        }
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUIPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUIPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUIPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIPedido.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUIPedido().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Panel_Cliente;
    private javax.swing.JPanel Panel_Item_Pedido;
    private javax.swing.JPanel Panel_Pagamento;
    private javax.swing.JPanel Panel_Pedido;
    private javax.swing.JPanel Panel_Vendedor;
    private javax.swing.ButtonGroup btgPagamento;
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnConsultarCliente;
    private javax.swing.JButton btnConsultarPedido;
    private javax.swing.JButton btnConsultarProduto;
    private javax.swing.JButton btnConsultarVendedor;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnIncluir;
    private javax.swing.JButton btnRemover;
    private javax.swing.JButton btnSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbnPrazo;
    private javax.swing.JRadioButton rbnVista;
    private javax.swing.JTable tblItemPedido;
    private javax.swing.JFormattedTextField txfCPFCliente;
    private javax.swing.JFormattedTextField txfCPFVendedor;
    private javax.swing.JFormattedTextField txfData;
    private javax.swing.JTextField txtCodigoProduto;
    private javax.swing.JTextField txtDescricaoProduto;
    private javax.swing.JTextField txtNomeCliente;
    private javax.swing.JTextField txtNomeVendedor;
    private javax.swing.JTextField txtNumPedido;
    private javax.swing.JTextField txtQtdItem;
    private javax.swing.JTextField txtQtdVendida;
    private javax.swing.JTextField txtTotalPedido;
    // End of variables declaration//GEN-END:variables
    private Conexao conexao = null;
        
    private DaoPedido daoPedido = null;
    private DaoProduto daoProduto = null;
    private DaoItemPedido daoItemPedido = null;
    private DaoCliente daoCliente = null;
    private DaoVendedor daoVendedor = null;
    
    private Pedido pedido = null;
    private Produto produto = null;
    private ItemPedido item = null;
    private Cliente cliente = null;
    private Vendedor vendedor = null;
    
    DefaultTableModel modTblItem;
    private int qtdLinha = 0;
    private double valorTotal = 0;
}
