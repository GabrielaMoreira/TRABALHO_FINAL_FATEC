package fatec.poo.control;

import fatec.poo.model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DaoProduto {
    private Connection conn;

    public DaoProduto(Connection conn) {
        this.conn = conn;
    }
    
    public void inserir(Produto produto){
        PreparedStatement ps = null;
        
        try{
            ps = conn.prepareStatement("INSERT INTO POO_PRODUTO"
                                                    + "(CODIGO, "
                                                    + "DESCRICAO, "
                                                    + "QTDEESTOQUE, "
                                                    + "UNIDADEMEDIDA, "
                                                    + "PRECO, "
                                                    + "ESTOQUEMINIMO) "
                                                    + "VALUES (?,?,?,?,?,?)");
            
            ps.setString(1, produto.getCodigo());
            ps.setString(2, produto.getDescricao());
            ps.setDouble(3, produto.getQtdeEstoque());
            ps.setString(4, produto.getUnidadeMedida());
            ps.setDouble(5, produto.getPreco());
            ps.setDouble(6, produto.getEstoqueMinimo());
            
            ps.execute();
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }
    }
    
    public Produto consultar(String codigo){
        Produto p = null;
        PreparedStatement ps = null;
        
        try{
            ps = conn.prepareStatement("SELECT * FROM POO_PRODUTO WHERE CODIGO = ?");
            
            ps.setString(1, codigo);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                p = new Produto(codigo, rs.getString("DESCRICAO"));
                p.setQtdeEstoque(rs.getDouble("QTDEESTOQUE"));
                p.setUnidadeMedida(rs.getString("UNIDADEMEDIDA"));
                p.setPreco(rs.getDouble("PRECO"));
                p.setEstoqueMinimo(rs.getDouble("ESTOQUEMINIMO"));
            }
            
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }
        return(p);
    }
    
    public void alterar(Produto produto){
        PreparedStatement ps = null;
        
        try{
            ps = conn.prepareStatement("UPDATE POO_PRODUTO SET "
                                                + "DESCRICAO = ?, "
                                                + "QTDEESTOQUE = ?, "
                                                + "UNIDADEMEDIDA = ?, "
                                                + "PRECO = ?, "
                                                + "ESTOQUEMINIMO = ? "
                                                + "WHERE CODIGO = ?");
            
            ps.setString(1, produto.getDescricao());
            ps.setDouble(2, produto.getQtdeEstoque());
            ps.setString(3, produto.getUnidadeMedida());
            ps.setDouble(4, produto.getPreco());
            ps.setDouble(5, produto.getEstoqueMinimo());
            ps.setString(6, produto.getCodigo());
            
            ps.execute();
            
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }
    }
    
    public void excluir(Produto produto){
        PreparedStatement ps = null;
        
        try{
            ps = conn.prepareStatement("DELETE FROM POO_PRODUTO WHERE CODIGO = ?");
            
            ps.setString(1, produto.getCodigo());
            
            ps.execute();
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }
    }
    
    public void baixarEstoque(Produto produto){
        
        PreparedStatement ps = null;
        
        try{
            ps = conn.prepareStatement("UPDATE POO_PRODUTO SET QTDEESTOQUE = ? "
                                                 + "WHERE CODIGO = ?");
            
            ps.setDouble(1, produto.getQtdeEstoque());
            ps.setString(2, produto.getCodigo());            
            
            ps.execute();
            
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }
        
    }
}
