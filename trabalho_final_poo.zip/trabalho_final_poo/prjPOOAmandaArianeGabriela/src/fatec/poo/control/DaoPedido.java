package fatec.poo.control;

import java.sql.Connection;

import fatec.poo.model.Cliente;
import fatec.poo.model.Pedido;
import fatec.poo.model.Vendedor;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DaoPedido {
    private Connection conn;
    
    public DaoPedido(Connection conn){
        this.conn = conn;
    }
    
    public Pedido consultar(String numPedido){
       
       //ABRINDO CONEXÕES COM OUTRAS DATA ACCESS OBJECT
       DaoCliente daoCliente = new DaoCliente(conn);
       DaoVendedor daoVendedor = new DaoVendedor(conn);
        
       Pedido pedido = null;
       Cliente cliente = null;
       Vendedor vendedor = null;
       PreparedStatement ps = null;
             
       try{
           ps = conn.prepareStatement("SELECT * FROM POO_PEDIDO WHERE NUMERO = ?");
            
           ps.setString(1, numPedido);
           ResultSet rs = ps.executeQuery();
            
           if(rs.next()){
               
               //PESQUISANDO DADOS DO OBJETO ATRAVÉS DA COLUNA DA TABELA PEDIDO CORRESPONDENTE (REFERENCIA)
               cliente = daoCliente.consultar(rs.getString("CPFCLI"));
               vendedor = daoVendedor.consultar(rs.getString("CPFVEND"));
               
               pedido = new Pedido(numPedido, rs.getString("DATAEMISSAO"));
               pedido.setDataPagto(rs.getString("DATAPAGTO"));
               pedido.setSituacao(rs.getBoolean("SITUACAO"));
               pedido.setFormaPagto(rs.getBoolean("FORMAPAGTO"));
               pedido.setCliente(cliente);
               pedido.setVendedor(vendedor);
           }
           
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }       
       return (pedido);
    }
    
    public void inserir(Pedido numPedido){
        
        PreparedStatement ps = null;
        
        try{
            
            ps = conn.prepareCall("INSERT INTO POO_PEDIDO"
                                                + "(NUMERO, "
                                                + "DATAEMISSAO, "
                                                + "FORMAPAGTO, "
                                                + "CPFCLI, "
                                                + "CPFVEND, "
                                                + "SITUACAO, "
                                                + "DATAPAGTO) "
                                                + "VALUES (?,?,?,?,?,?,?)");
            
            ps.setString(1, numPedido.getNumero());
            ps.setString(2, numPedido.getDataEmissao());
            ps.setBoolean(3, numPedido.isFormaPagto());
            ps.setString(4, numPedido.getCliente().getCpf());
            ps.setString(5, numPedido.getVendedor().getCpf());
            ps.setBoolean(6, numPedido.isSituacao());
            ps.setString(7, numPedido.getDataPagto());
            
            ps.execute();
            
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }    
        
    }
 
    public void excluir(Pedido numPedido){
        
        PreparedStatement ps = null;
        
        try{
            ps = conn.prepareStatement("DELETE FROM POO_PEDIDO WHERE NUMERO = ?");
            
            ps.setString(1, numPedido.getNumero());
            
            ps.execute();
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }
    }
}
