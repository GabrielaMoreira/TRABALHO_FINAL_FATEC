package fatec.poo.control;

import java.sql.Connection;

import fatec.poo.model.ItemPedido;
import fatec.poo.model.Pedido;
import fatec.poo.model.Produto;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/* @author GabrielaMoreira */
public class DaoItemPedido {
    
    private Connection conn;
    
    public DaoItemPedido(Connection conn){
        this.conn = conn;
    }
    
    public void inserir(ItemPedido item){
        
        PreparedStatement ps = null;
        
        try{
            
            ps = conn.prepareCall("INSERT INTO POO_ITEMPEDIDO"
                                                + "(SEQUENCIA, "
                                                + "QTDEVENDIDA, "
                                                + "NUMERO_PEDIDO, "
                                                + "CODIGO_PRODUTO) "
                                                + "VALUES (?,?,?,?)");
            
            ps.setInt(1, item.getSequencia());
            ps.setDouble(2, item.getQtdeVendida());
            ps.setString(3, item.getPedido().getNumero());
            ps.setString(4, item.getProduto().getCodigo());
            
            ps.execute();
            
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }    
    }
    
    public ArrayList consultar(Pedido pedido){
        
        Conexao conexao = new Conexao("BD1721003","BD1721003");
        conexao.setDriver("oracle.jdbc.driver.OracleDriver");
        conexao.setConnectionString("jdbc:oracle:thin:@localhost:1521:xe");
        
        DaoProduto daoProduto = new DaoProduto(conexao.conectar());
        
        ItemPedido ip = null;
        PreparedStatement ps = null;
        
        ArrayList<ItemPedido> itensPedido = new ArrayList<ItemPedido>();
        
        try{
            ps = conn.prepareStatement("SELECT * FROM POO_ITEMPEDIDO WHERE numero_pedido = ?");
            ps.setInt(1, Integer.parseInt(pedido.getNumero()));
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                ip = new ItemPedido(rs.getInt("sequencia"), rs.getDouble("qtdeVendida"), daoProduto.consultar(rs.getString("codigo_produto")));
                ip.setPedido(pedido);
                itensPedido.add(ip);
            }
            /*if(rs.next()){
                ip = new ItemPedido(rs.getInt("sequencia"), rs.getDouble("qtdeVendida"), produto);
            }*/
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }                 
        return(itensPedido);
    }
    
    public void excluir(ItemPedido item){
        PreparedStatement ps = null;
        
        try{
            ps = conn.prepareStatement("DELETE FROM POO_ITEMPEDIDO WHERE NUMERO_PEDIDO = ?");
            
            ps.setString(1, item.getPedido().getNumero());
            
            ps.execute();
        }catch(SQLException ex){
            System.out.println(ex.toString());
        }
    }
}
