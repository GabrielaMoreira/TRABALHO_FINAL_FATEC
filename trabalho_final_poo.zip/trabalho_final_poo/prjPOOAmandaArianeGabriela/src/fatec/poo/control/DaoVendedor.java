/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fatec.poo.control;

import fatec.poo.model.Vendedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author 0030481721003
 */
public class DaoVendedor {
   private Connection conn;

    public DaoVendedor(Connection conn) {
        this.conn = conn;
    }
   public Vendedor consultar (String cpf){
       Vendedor v = null;
       
       PreparedStatement ps = null;
       try{
           ps = conn.prepareStatement("SELECT * FROM POO_VENDEDOR WHERE CPF = ?");
           
           ps.setString(1, cpf);
           ResultSet rs = ps.executeQuery();
           
           if(rs.next()){
            v = new Vendedor (cpf, rs.getString("NOME"), rs.getDouble("SALARIOBASE"));
            v.setEndereco(rs.getString("ENDERECO"));
            v.setCidade(rs.getString("CIDADE"));
            v.setUf(rs.getString("UF"));
            v.setCep(rs.getString("CEP"));
            v.setDdd(rs.getString("DDD"));
            v.setTelefone(rs.getString("TELEFONE"));
            v.setTaxaComissao(rs.getDouble("TAXACOMISSAO"));
            //v.setTaxaComissao(rs.getDouble("TAXACOMISSAO"));
           }
                     
       } catch(SQLException ex){
           System.out.println(ex.toString());
       }
       return(v);
   }
   public void incluir(Vendedor vendedor){
       PreparedStatement ps = null;
       
       try{
           ps = conn.prepareStatement("INSERT INTO POO_VENDEDOR (CPF,NOME,ENDERECO,CIDADE,UF,CEP,DDD,TELEFONE,SALARIOBASE,TAXACOMISSAO)" +
                                      "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
           
           ps.setString(1, vendedor.getCpf());
           ps.setString(2, vendedor.getNome());
           ps.setString(3, vendedor.getEndereco());
           ps.setString(4, vendedor.getCidade());
           ps.setString(5, vendedor.getUf());
           ps.setString(6, vendedor.getCep());
           ps.setString(7, vendedor.getDdd());
           ps.setString(8, vendedor.getTelefone());
           ps.setDouble(9, vendedor.getSalarioBase());
           ps.setDouble(10, vendedor.getTaxaComissao());
           
           ps.execute();
       }catch(SQLException ex){
           System.out.println(ex.toString());
       }
   }
   public void alterar(Vendedor vendedor){
       PreparedStatement ps = null;
       
       try{
           ps = conn.prepareStatement("UPDATE POO_VENDEDOR SET "
                                            + "NOME = ?, "
                                            + "ENDERECO = ?, "
                                            + "CIDADE = ?, " 
                                            + "UF = ?, "
                                            + "CEP = ?, "
                                            + "DDD = ?, "
                                            + "TELEFONE = ?, "
                                            + "SALARIOBASE = ?, "
                                            + "TAXACOMISSAO = ? " 
                                            + "WHERE CPF = ?");
           
           ps.setString(1, vendedor.getNome());
           ps.setString(2, vendedor.getEndereco());
           ps.setString(3, vendedor.getCidade());
           ps.setString(4, vendedor.getUf());
           ps.setString(5, vendedor.getCep());
           ps.setString(6, vendedor.getDdd());
           ps.setString(7, vendedor.getTelefone());
           ps.setDouble(8, vendedor.getSalarioBase());
           ps.setDouble(9, vendedor.getTaxaComissao());
           ps.setString(10,vendedor.getCpf());
           
           ps.execute();
           
       }catch(SQLException ex){
           System.out.println(ex.toString());
       }
   }
   public void excluir(Vendedor vendedor){
       PreparedStatement ps = null;
       
       try{
           ps = conn.prepareStatement("DELETE FROM POO_VENDEDOR WHERE CPF = ?");
           
           ps.setString(1, vendedor.getCpf());
           
           ps.execute();
       }catch(SQLException ex){
           System.out.println(ex.toString());
       }
   }
}
