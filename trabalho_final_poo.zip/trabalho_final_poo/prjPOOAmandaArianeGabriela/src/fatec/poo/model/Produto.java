package fatec.poo.model;
/**
 *
 * @author 0030481721003
 */
public class Produto {
    private String codigo;    
    private String descricao;
    private double qtdeEstoque;
    private String unidadeMedida;
    private double preco;
    private double estoqueMinimo;

    public Produto(String codigo, String descricao) {
        this.codigo = codigo;
        this.descricao = descricao;
    }
    public String getDescricao() {
        return descricao;
    }    
    public double getQtdeEstoque() {
        return qtdeEstoque;
    }
    public String getUnidadeMedida() {
        return unidadeMedida;
    }
    public double getPreco() {
        return preco;
    }
    public double getEstoqueMinimo() {
        return estoqueMinimo;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public void setQtdeEstoque(double qtdeEstoque) {
        this.qtdeEstoque = qtdeEstoque;
    }
    public void setUnidadeMedida(String unidadeMedida) {
        this.unidadeMedida = unidadeMedida;
    }
    public void setPreco(double preco) {
        this.preco = preco;
    }
    public void setEstoqueMinimo(double estoqueMinimo) {
        this.estoqueMinimo = estoqueMinimo;
    }  
    
    //add
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    //METODO VERIFICA CODIGO NUMERICO: VALIDO = TRUE, INVALIDO = FALSE
    public static boolean VerificaCodigo(String codigo){
        int cont, tamanho = codigo.length(), digito = 0;
        boolean valido = true;
        
        for(cont = 0; cont < tamanho; cont++){
            if(Character.isDigit(codigo.charAt(cont)))
                digito++;               
        }
        
        if(digito != tamanho)
            valido = false;
        
        return(valido);
    }
    
    //METODO VERIFICA VALOR NUMERICO OU PONTO (PARA CAMPOS DOUBLE): VALIDO = TRUE, INVALIDO = FALSE
    public static boolean VerificaValor(String valor){
        int cont, tamanho = valor.length(), digito = 0;
        boolean valido = true;
        
        for(cont = 0; cont < tamanho; cont++){
            if(Character.isDigit(valor.charAt(cont)) || valor.charAt(cont) == '.')
                digito++;
        }
        
        if(digito != tamanho)
            valido = false;
        
        return(valido);
    }
}
