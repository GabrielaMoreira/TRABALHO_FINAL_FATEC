package fatec.poo.model;

public class ItemPedido {
    private int sequencia;
    private double qtdeVendida;
    private Produto produto;
    private Pedido pedido;   

    //CONSTRUTOR
    public ItemPedido(int sequencia, double qtdeVendida, Produto produto) {
        this.sequencia = sequencia;
        this.qtdeVendida = qtdeVendida;
        this.produto = produto;
    }
    
    //GETTERS
    public int getSequencia() {
        return sequencia;
    }
    public Produto getProduto() {
        return produto;
    }
    public double getQtdeVendida() {
        return qtdeVendida;
    }
    public Pedido getPedido() {
        return pedido;
    }
    
    
    //SETTERS
    public void setQtdeVendida(double qtdeVendida) {
        this.qtdeVendida = qtdeVendida;
    }
    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }
    
        
    //MÉTODOS
    public void baixaEstoque(double quantidade){
        produto.setQtdeEstoque(produto.getQtdeEstoque() - quantidade);
    }
}