package fatec.poo.model;

import java.util.ArrayList;

public class Pedido {
    private String numero;
    private String dataEmissao;
    private String dataPagto;
    private boolean formaPagto;
    private boolean situacao;
    private ArrayList<ItemPedido> itemPedido;
    private Cliente cliente;   
    private Vendedor vendedor;
    

    //CONSTRUTOR
    public Pedido(String numero, String dataEmissao) {
        this.numero = numero;
        this.dataEmissao = dataEmissao;
        itemPedido = new ArrayList<ItemPedido>();
    }
    
    //GETTERS
    public String getNumero() {
        return numero;
    }
    public String getDataEmissao() {
        return dataEmissao;
    }
    public String getDataPagto() {
        return dataPagto;
    }
    public Cliente getCliente() {
        return cliente;
    }
    public boolean isFormaPagto() {
        return formaPagto;
    }
    public boolean isSituacao() {
        return situacao;
    }
    public Vendedor getVendedor() {
        return vendedor;
    }
    public ArrayList<ItemPedido> getItemPedido(){
        return itemPedido;
    }
    
    
    //SETTERS
    public void setDataPagto(String dataPagto) {
        this.dataPagto = dataPagto;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    public void setFormaPagto(boolean formaPagto) {
        this.formaPagto = formaPagto;
    }
    public void setSituacao(boolean situacao) {
        this.situacao = situacao;
    }
    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }  
    
    //MÉTODOS
    public void addItemPedido(ItemPedido i){
        itemPedido.add(i);
        i.setPedido(this);
        
        if(formaPagto == true){
            cliente.setLimiteDisp(cliente.getLimiteDisp() - (i.getProduto().getPreco() * i.getQtdeVendida()));
            i.baixaEstoque(i.getQtdeVendida());
        }
    }
    
}