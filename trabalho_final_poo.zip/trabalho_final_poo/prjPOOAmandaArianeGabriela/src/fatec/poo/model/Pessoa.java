package fatec.poo.model;

import java.util.InputMismatchException;

/**
 *
 * @author 0030481721003
 */
public class Pessoa {
    private String cpf;
    private String nome;
    private String endereco;
    private String cidade;
    private String uf;
    private String cep;
    private String ddd;
    private String telefone;

    public Pessoa(String cpf, String nome) {
        this.cpf = cpf;
        this.nome = nome;
    }
    public String getCpf() {
        return cpf;
    }
    public String getNome() {
        return nome;
    }
    public String getEndereco() {
        return endereco;
    }
    public String getCidade() {
        return cidade;
    }
    public String getUf() {
        return uf;
    }
    public String getCep() {
        return cep;
    }
    public String getDdd() {
        return ddd;
    }
    public String getTelefone() {
        return telefone;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
    public void setUf(String uf) {
        this.uf = uf;
    }
    public void setCep(String cep) {
        this.cep = cep;
    }
    public void setDdd(String ddd) {
        this.ddd = ddd;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public static boolean validarCPF(String cpf){
        String numFormatado[] = new String[11];
        int digitosCPF[] = new int[11];
        int cont, cont2, cont3, igual=0, digitoVerificador1=0, digitoVerificador2=0;
        boolean valido = true;
        
             
        for(cont3 = 0; cont3 < 11;cont3++){/*Armazenando cada digito do cpf no numeroFormato*/
            numFormatado[cont3] = cpf.substring(cont3, cont3 + 1);
        }
        
        for(cont = 1; cont <= 10; cont++)/* ------------------------------------------------- Verificao Numeros Iguais*/
	{
            if(numFormatado[cont-1].equals(numFormatado[cont]))
		igual++;	
	}	
	if(igual == 10)
            valido = false;		
			
	if(valido != false)
	{			
            for(cont = 0; cont < 11; cont++)/* ------------------------------------------------ Caracter para Inteiro*/
                    digitosCPF[cont] = Integer.parseInt(numFormatado[cont]);	

            //1)Validação primeiro digito verificador
            for(cont2 = 1, cont = 0; cont < 9; cont++, cont2++)
                    digitoVerificador1 = digitoVerificador1 + cont2 * digitosCPF[cont];

            digitoVerificador1 = digitoVerificador1 % 11;
            if(digitoVerificador1 == 10)
                digitoVerificador1 = 0;
				
                //2)Validação segundo digito verificador
                for(cont2 = 11, cont = 0; cont < 10; cont++, cont2--)
                {
                        digitoVerificador2 = digitoVerificador2 + cont2 * digitosCPF[cont];

                }
                digitoVerificador2 = (digitoVerificador2 * 10) % 11;
                if(digitoVerificador2 == 10)
                        digitoVerificador2 = 0;
                
                if(digitoVerificador1 != digitosCPF[9] || digitoVerificador2 != digitosCPF[10])
                    valido = false;
	}
        
	return(valido);     
    }	
}	