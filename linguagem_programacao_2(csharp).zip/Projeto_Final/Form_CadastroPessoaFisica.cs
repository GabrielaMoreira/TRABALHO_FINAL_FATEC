﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoFinal
{
    public partial class Form_CadastroPessoaFisica : Form
    {
        public Form_CadastroPessoaFisica()
        {
            InitializeComponent();
        }
        
        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            //DECLARAÇÃO DE VARIAVEIS
            string error, nome, sexo, estadoCivil, email, dataNascimento, telefone_semFormato, telefone_comFormato, CPF_semFormato, CPF_comFormato;
            int comprimentoCPF, comprimentoTelefone; 
            bool primeiroDigito, segundoDigito, numerosIdenticos;
            DateTime data;            



            //LABEL DE AVISO (FALTA PREENCHER CAMPO)
            lblAvisoNome.Visible = false;
            lblAvisoCPF.Visible = false;
            lblAvisoEstadoCivil.Visible = false;
            lblAvisoSexo.Visible = false;
            lblAvisoEmail.Visible = false;
            lblAvisoTelefone.Visible = false;
            lblAvisoDataNascimento.Visible = false;



            //ARMAZENANDO DADOS NAS VARIAVEIS
            error = "";            
            nome = txtNome.Text;
            estadoCivil = cbEstadoCivil.Text;            
            email = txtEmail.Text;
            dataNascimento = mtxtDataNascimento.Text;

            if (rbMasculino.Checked == true)
                sexo = rbMasculino.Text;
            else if (rbFeminino.Checked == true)
                sexo = rbFeminino.Text;
            else
                sexo = "";

            CPF_semFormato = mtxtCPF.Text;           
            comprimentoCPF = CPF_semFormato.Length;   
            
            telefone_semFormato = mtxtTelefone.Text;           
            comprimentoTelefone = telefone_semFormato.Length;        
            
            

            //VERIFICANDO SE TODOS OS CAMPOS FORAM PREENCHIDOS OU INVALIDOS
            if (nome == "")
            {
                error = error + "O NOME é de preenchimento obrigatório\n";
                lblAvisoNome.Visible = true;
            }
            if(estadoCivil == "")
            {
                error = error + "O ESTADO CIVIL deve ser informado\n";
                lblAvisoEstadoCivil.Visible = true;
            }            
            if(email == "")
            {
                error = error + "O EMAIL deve ser informado\n";
                lblAvisoEmail.Visible = true;
            }
            if(sexo == "")
            {
                error = error + "O SEXO deve ser informado\n";
                lblAvisoSexo.Visible = true;
            }            
            if (telefone_semFormato == "" || comprimentoTelefone < 10)
            {
                error = error + "O TELEFONE é de preenchimento obrigatório\n";
                lblAvisoTelefone.Visible = true;
            }

            if(dataNascimento == "")
            {
                error = error + "A DATA NASCIMENTO é de preechimento obrigatório\n";
                lblAvisoDataNascimento.Visible = true;
            } 
            else
            {
                if (DateTime.TryParse(dataNascimento,out data))
                {
                    dataNascimento = Convert.ToDateTime(dataNascimento).ToString("dd/MM/yyyy");  /*Coloca formato*/
                }
                else
                {
                    error = error + "A DATA NASCIMENTO informada é inválida\n";
                    lblAvisoDataNascimento.Visible = true;
                }
            }
            
            if (CPF_semFormato == "" || comprimentoCPF < 11)
            {
                error = error + "O CPF é de preenchimento obrigatório\n";
                lblAvisoCPF.Visible = true;
            }
            else
            {
                /*VALIDAÇÃO DO CPF*/
                numerosIdenticos = ROTINAS.DigitosIguaisCPF(CPF_semFormato);
                primeiroDigito = ROTINAS.Verifica_primeiroDigito(CPF_semFormato);
                segundoDigito = ROTINAS.Verifica_segundoDigito(CPF_semFormato);

                if (numerosIdenticos == true || primeiroDigito == false || segundoDigito == false)
                {
                    error = error + "O CPF informado é inválido\n";
                    lblAvisoCPF.Visible = true;
                }    
            }            



            //MOSTRANDO RESULTADOS
            if (error != "")
                MessageBox.Show(error, "OCORRERAM OS SEGUINTES ERROS NO FORMULÁRIO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
               CPF_comFormato = Convert.ToUInt64(CPF_semFormato).ToString(@"000\.000\.000\-00"); /*Coloca formato*/
               telefone_comFormato = Convert.ToUInt64(telefone_semFormato).ToString(@"(00) 0000-0000");

               MessageBox.Show("OS DADOS CADASTRADOS FORAM: \n\nCPF: " + CPF_comFormato + "\nNome: " + nome.ToUpper() + "\nData de Nascimento: " + dataNascimento + "\nSexo: " + sexo.ToUpper() + "\nEstado Civil: " + estadoCivil +  "\nTelefone: " + telefone_comFormato + "\nE-mail: " +email.ToUpper(), "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
               LimpaCampos();
            }

        }



        //FUNÇÃO PARA LIMPAR CAMPOS
        public void LimpaCampos()
        {
            txtNome.Text = "";
            mtxtDataNascimento.Text = "";
            mtxtCPF.Text = "";
            cbEstadoCivil.SelectedIndex = -1;
            rbFeminino.Checked = false;
            rbMasculino.Checked = false;
            txtEmail.Text = "";
            mtxtTelefone.Text = "";
        }
    }
}
