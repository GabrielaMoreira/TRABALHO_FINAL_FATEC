﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoFinal
{
    public partial class Form_Cotacao : Form
    {
        public Form_Cotacao()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            //DECLARAÇÃO DE VARIAVEIS
            string error, nomeFornecedor, produto, quantidade, valorUnitario, valorTotal;

            //LABEL DE AVISO (FALTA PREENCHER CAMPO)                      
            lblAvisoFornecedor.Visible = false;
            lblAvisoProduto.Visible = false;
            lblAvisoQuantidade.Visible = false;
            lblAvisoValorUnitario.Visible = false;



            //ARMAZENANDO DADOS NAS VARIAVEIS
            error = "";
            nomeFornecedor = txtFornecedor.Text;
            produto = cbProduto.Text;
            quantidade = txtQuantidade.Text;
            valorUnitario = txtValorUnitario.Text;
            valorTotal = lblValorTotal.Text;


            //VERIFICANDO SE TODOS OS CAMPOS FORAM PREENCHIDOS OU INVALIDOS
            if (nomeFornecedor == "")
            {
                error = error + "O FORNECEDOR deve ser informado\n";
                lblAvisoFornecedor.Visible = true;
            }
            if(produto == "")
            {
                error = error + "O PRODUTO deve ser informado\n";
                lblAvisoProduto.Visible = true;
            }
            if(quantidade == "")
            {
                error = error + "A QUANTIDADE deve ser informada\n";
                lblAvisoQuantidade.Visible = true;
            }
            if(valorUnitario == "" || valorUnitario == "0,00")
            {
                error = error + "O VALOR UNITÁRIO deve ser informada\n";
                lblAvisoValorUnitario.Visible = true;
            }



            //MOSTRANDO RESULTADOS
            if (error != "")
                MessageBox.Show(error, "OCORRERAM OS SEGUINTES ERROS NO FORMULÁRIO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                MessageBox.Show("OS DADOS GRAVADOS FORAM: \n\nNome Fornecedor: " + nomeFornecedor.ToUpper() + "\nProduto: " + produto + "\nQuantidade: " + quantidade + "\nValor Unitário: " + valorUnitario + "\nValor Total: " + valorTotal, "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaCampos();
            }
                

        }



        //CALCULANDO VALOR TOTAL (ATRAVES DE QUANTIDADE)
        private void txtQuantidade_TextChanged(object sender, EventArgs e)
        {
            if (txtValorUnitario.Text != "" && txtValorUnitario.Text != "0,00" && txtQuantidade.Text != "")
            {
                double total;
                total = Convert.ToInt32(txtQuantidade.Text) * Convert.ToDouble(txtValorUnitario.Text);
                lblValorTotal.Text = "R$ " + String.Format("{0:0.00}", total);
            }
            else
                lblValorTotal.Text = "R$ 0,00";
        }



        //CHAMADA FUNÇÃO PARA MASCARA MOEDA E CALCULANDO VALOR TOTAL (ATRAVES DE PRECO UNITÁRIO)
        private void txtValorUnitario_TextChanged(object sender, EventArgs e)
        {
            double total;

            ROTINAS.TextBoxMoeda(ref txtValorUnitario);

            if (txtQuantidade.Text != "" && txtValorUnitario.Text != "0,00" && txtValorUnitario.Text != "")
            {
                total = Convert.ToInt32(txtQuantidade.Text) * Convert.ToDouble(txtValorUnitario.Text);
                lblValorTotal.Text = "R$ " + String.Format("{0:0.00}", total);
            }
            else
                lblValorTotal.Text = "R$ 0,00";          
        }



        //BLOQUEAR DIGITOS PARA APENAS NUMEROS E BACKSPACE
        private void txtQuantidade_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)8) /* 8 é o código do backspace em tabela ASCII*/
            {
                e.Handled = true;
            }
        }
        private void txtValorUnitario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)8) 
            {
                e.Handled = true;
            }
        }



        //FUNÇÃO PARA LIMPAR CAMPOS
        public void LimpaCampos()
        {
            txtFornecedor.Text = "";
            cbProduto.SelectedIndex = -1;
            txtQuantidade.Text = "";
            txtValorUnitario.Text = "";
            lblValorTotal.Text = "R$ 0.00";
            
        }
        
    }
}
