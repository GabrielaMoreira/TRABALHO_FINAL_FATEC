﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoFinal
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form_MenuPrincipal());
        }
    }

    public static class ROTINAS
    {
        /*Função verifica se todos os digitos do cpf são iguais*/
        public static bool DigitosIguaisCPF(string cpf_semFormato)
        {
            int[] numerosCPF = new int[12];
            int cont, digitoIgual;

            digitoIgual = 0;

            for (cont = 0; cont < 11; cont++)
              numerosCPF[cont] = cpf_semFormato[cont] - 48;               

            for (cont = 1; cont < 11; cont++)
            {
                if (numerosCPF[cont] == numerosCPF[cont-1])
                    digitoIgual++;
            }

            if (digitoIgual == 10)
                return true;
            else
                return false;
        }

        /*Função valida primeiro digito verificador do cpf*/
        public static bool Verifica_primeiroDigito(string cpf_semFormato)
        {
            int[] numerosCPF = new int[12];
            int cont, primeiroDigito;

            primeiroDigito = 0;

            for (cont = 0; cont < 11; cont++)
                numerosCPF[cont] = cpf_semFormato[cont] - 48;

            for (cont = 10; cont > 1; cont--)
                primeiroDigito = primeiroDigito + (numerosCPF[10 - cont] * cont);

            primeiroDigito = (primeiroDigito * 10) % 11;
            if (primeiroDigito == 10)
                primeiroDigito = 0;

            if (primeiroDigito == numerosCPF[9])
                return true;
            else
                return false;
        }

        /*Função valida segundo digito verificador do cpf*/
        public static bool Verifica_segundoDigito(string cpf_semFormato)
        {
            int[] numerosCPF = new int[12];
            int cont, segundoDigito;

            segundoDigito = 0;

            for (cont = 0; cont < 11; cont++)
                numerosCPF[cont] = cpf_semFormato[cont] - 48;

            for (cont = 11; cont > 1; cont--)
                segundoDigito = segundoDigito + (numerosCPF[11 - cont] * cont);

            segundoDigito = (segundoDigito * 10) % 11;
            if (segundoDigito == 10)
                segundoDigito = 0;

            if (segundoDigito == numerosCPF[10])
                return true;
            else
                return false;
        }

        /*Mascara dinamica de moeda*/
        public static void TextBoxMoeda(ref TextBox txt)
        {
            string n = string.Empty;
            double v = 0;
            try
            {
                n = txt.Text.Replace(",", "").Replace(".", "");
                if (n.Equals(""))
                    n = "";
                n = n.PadLeft(3, '0');
                if (n.Length > 3 & n.Substring(0, 1) == "0")
                    n = n.Substring(1, n.Length - 1);
                v = Convert.ToDouble(n) / 100;
                txt.Text = string.Format("{0:N}", v);
                txt.SelectionStart = txt.Text.Length;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }       

    }
}
