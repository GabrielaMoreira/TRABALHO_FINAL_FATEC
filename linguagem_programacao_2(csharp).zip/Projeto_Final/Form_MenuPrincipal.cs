﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoFinal
{
    public partial class Form_MenuPrincipal : Form
    {
        public Form_MenuPrincipal()
        {
            InitializeComponent();
        }

        private void pESSOAFISICAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form_CadastroPessoaFisica cadastroPessoaFisica = new Form_CadastroPessoaFisica();
            cadastroPessoaFisica.Show();
        }

        private void cOTAÇÃOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form_Cotacao cotacao = new Form_Cotacao();
            cotacao.Show();
        }

        private void sAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
